# Do'konchi — Vercel'ga joylash

Kichik do'konlar uchun savdo tizimi. Ma'lumotlar Firebase Firestore bazasida saqlanadi, sayt Vercel'da turadi. Ikkalasi ham bepul.

## Fayllar

| Fayl | Nima uchun |
|---|---|
| `index.html` | Saytning o'zi |
| `firebase-config.js` | Firebase kalitlari — **shuni to'ldirasiz** |
| `firestore.rules` | Baza qoidalari (Firebase'ga nusxalanadi) |
| `vercel.json` | Vercel sozlamalari |

## 1-qadam. Firebase bazasini ochish

1. https://console.firebase.google.com ga Google akkaunt bilan kiring.
2. **Add project** → nom bering (masalan `dokonchi`) → Google Analytics shart emas → **Create project**.
3. Chap menyuda **Build → Firestore Database** → **Create database**.
   - Joylashuv: `eur3 (europe-west)` yoki yaqinroq biror Yevropa hududi.
   - **Start in production mode** ni tanlang.
4. Firestore ichida **Rules** bo'limini oching, u yerdagi matnni o'chirib, `firestore.rules` faylidagi matnni qo'ying → **Publish**.
5. Chap tepada ⚙️ → **Project settings** → pastda **Your apps** → **`</>`** (Web) belgisini bosing.
   - Ilova nomini yozing (masalan `dokonchi-web`), Hosting belgilamang → **Register app**.
   - Chiqqan `firebaseConfig = { ... }` ichidagi qiymatlarni `firebase-config.js` fayliga ko'chiring.

## 2-qadam. Vercel'ga joylash

**GitHub orqali (tavsiya etiladi):**
1. GitHub'da yangi repository oching (masalan `dokonchi`) va shu papkadagi 4 ta faylni yuklang.
2. https://vercel.com → **Add New… → Project** → repository'ni tanlang → **Import**.
3. Framework Preset: **Other**. Build sozlamalarini o'zgartirmang → **Deploy**.
4. Bir daqiqada `dokonchi-xxxx.vercel.app` manzili tayyor bo'ladi.

**Yoki buyruq qatori orqali:** papka ichida `npx vercel` → so'ralgan savollarga Enter → keyin `npx vercel --prod`.

Keyin GitHub'dagi faylni o'zgartirsangiz, Vercel saytni o'zi yangilaydi.

## 3-qadam. Birinchi ishga tushirish

1. Saytni oching → **Do'kon egasi** → PIN `1234`.
2. **Sozlamalar**da do'kon nomini yozing va PIN-kodni **albatta** almashtiring.
3. **Tovarlar**dan tovarlarni qo'shing.
4. Sotuvchilarga sayt manzilini bering: ular **Sotuvchi → Ro'yxatdan o'tish** qiladi, siz **Sotuvchilar** bo'limida tasdiqlaysiz.

## Xavfsizlik haqida

Bu versiyada sayt manzilini bilgan odam bazaga ulanishi mumkin. PIN-kodlar sotuvchini ega panelidan ajratadi, lekin dasturchi bo'lgan odam bazaga to'g'ridan-to'g'ri kira oladi. Kichik do'kon uchun bu odatda yetarli. Sayt manzilini faqat o'z sotuvchilaringizga bering. Keyinchalik kuchliroq himoya kerak bo'lsa, Firebase Authentication (telefon yoki Google orqali kirish) qo'shiladi.

Firebase bepul rejasi kuniga 50 000 o'qish va 20 000 yozishgacha ruxsat beradi. Bitta kichik do'konga bu bemalol yetadi.
