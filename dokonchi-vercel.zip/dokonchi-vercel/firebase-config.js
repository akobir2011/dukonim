// Firebase loyihasi: maydonbor-f1ce6
window.FIREBASE_CONFIG = {
  apiKey: "AIzaSyB8YgHO7BBEyt_Is0DGjLUQdc1oR-tBRMs",
  authDomain: "maydonbor-f1ce6.firebaseapp.com",
  projectId: "maydonbor-f1ce6",
  storageBucket: "maydonbor-f1ce6.firebasestorage.app",
  messagingSenderId: "879667942687",
  appId: "1:879667942687:web:d370ad6638fdeafd074c2a"
};
